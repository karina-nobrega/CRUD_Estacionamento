package com.controle_estacionamento.fachada;

import com.controle_estacionamento.dao.IDao;
import com.controle_estacionamento.dao.VeiculoDAO;
import com.controle_estacionamento.dominio.EntidadeDominio;
import org.springframework.stereotype.Service;

import java.sql.SQLException;
import java.util.List;

public class VeiculoFachada implements IFachada {
    private final IDao veiculoDao;

    public VeiculoFachada() throws SQLException {
        veiculoDao = new VeiculoDAO();
    }

    @Override
    public List<EntidadeDominio> getAll() throws SQLException {
        return veiculoDao.getAll();
    }

    @Override
    public EntidadeDominio getById(int id) throws SQLException {
        return veiculoDao.getById(id);
    }

    @Override
    public EntidadeDominio save(EntidadeDominio entidadeDominio) throws SQLException {
        return veiculoDao.save(entidadeDominio);
    }

    @Override
    public EntidadeDominio update(int id, EntidadeDominio entidadeDominio) throws SQLException {
        return veiculoDao.update(id, entidadeDominio);
    }

    @Override
    public Boolean delete(int id) throws SQLException {
        return veiculoDao.delete(id);
    }
}
