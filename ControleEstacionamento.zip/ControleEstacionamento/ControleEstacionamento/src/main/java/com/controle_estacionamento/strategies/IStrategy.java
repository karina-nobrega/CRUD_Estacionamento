package com.controle_estacionamento.strategies;

import com.controle_estacionamento.dominio.EntidadeDominio;

public interface IStrategy {

    Boolean processar(EntidadeDominio entidadeDominio);

}
