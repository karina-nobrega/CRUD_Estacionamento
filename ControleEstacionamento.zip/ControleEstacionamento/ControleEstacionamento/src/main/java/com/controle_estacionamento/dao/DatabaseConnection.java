package com.controle_estacionamento.dao;

import java.sql.Connection;
import java.sql.Driver;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DatabaseConnection {

    private static Connection conn;
    private static final String URL = "jdbc:mysql://localhost:3306/controleestacionamento";
    private static final String USER = "karina";
    private static final String PASSWORD = "1234";

    public static Connection getConnection() throws SQLException {
        conn = null;
        try{
            conn = DriverManager.getConnection(URL, USER, PASSWORD);
            return conn;
        }catch (SQLException error){
            throw new SQLException(error.getMessage());
        }
    }
}
