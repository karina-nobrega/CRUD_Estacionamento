package com.controle_estacionamento.fachada;

import com.controle_estacionamento.dao.RegistroDAO;
import com.controle_estacionamento.dominio.EntidadeDominio;
import com.controle_estacionamento.strategies.CalcularPreco;

import java.sql.SQLException;
import java.util.List;

public class RegistroFachada implements IFachada{
    private final RegistroDAO registroDao;
    private final CalcularPreco calcularPreco;

    public RegistroFachada() throws SQLException {
        registroDao = new RegistroDAO();
        calcularPreco = new CalcularPreco();
    }

    @Override
    public List<EntidadeDominio> getAll() throws SQLException {
        return registroDao.getAll();
    }

    @Override
    public EntidadeDominio getById(int id) throws SQLException {
        return registroDao.getById(id);
    }

    public List<EntidadeDominio> getByVeiculoId(int id) throws SQLException {
        return registroDao.getByVeiculoId(id);
    }

    @Override
    public EntidadeDominio save(EntidadeDominio entidadeDominio) throws SQLException {
        return registroDao.save(entidadeDominio);
    }

    @Override
    public EntidadeDominio update(int id, EntidadeDominio entidadeDominio) throws SQLException {
        calcularPreco.processar(entidadeDominio);
        return registroDao.update(id, entidadeDominio);
    }

    @Override
    public Boolean delete(int id) throws SQLException {
        return registroDao.delete(id);
    }
}
