package com.controle_estacionamento.strategies;

import com.controle_estacionamento.dominio.EntidadeDominio;
import com.controle_estacionamento.dominio.Registro;

import java.time.Duration;
import java.time.LocalDateTime;

public class CalcularPreco implements IStrategy {
    @Override
    public Boolean processar(EntidadeDominio entidadeDominio) {
        Registro registro = (Registro) entidadeDominio;

        LocalDateTime entrada = registro.getDataHoraEntrada();
        LocalDateTime saida = registro.getDataHoraSaida();

        Duration duration = Duration.between(entrada, saida);
        long diff = duration.toHours();

        if (diff < 1) {
            registro.setPreco(10.0);
        } else {
            registro.setPreco(10.0 + (diff - 1) * 5.0);
        }

        return true;

    }
}
