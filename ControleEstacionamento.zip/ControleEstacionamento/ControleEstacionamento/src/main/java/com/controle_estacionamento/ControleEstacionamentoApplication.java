package com.controle_estacionamento;

import com.controle_estacionamento.dao.DatabaseConnection;
import com.controle_estacionamento.dao.RegistroDAO;
import com.controle_estacionamento.dao.VeiculoDAO;
import com.controle_estacionamento.dominio.Registro;
import com.controle_estacionamento.dominio.Veiculo;
import com.controle_estacionamento.fachada.VeiculoFachada;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import java.sql.Connection;
import java.sql.SQLException;
import java.time.LocalDateTime;

@SpringBootApplication
public class ControleEstacionamentoApplication {

	public static void main(String[] args) throws SQLException {
		try{
			Connection conn = DatabaseConnection.getConnection();
			SpringApplication.run(ControleEstacionamentoApplication.class, args);
		}catch (SQLException erro){
			throw new SQLException("An error occurred while connection to the database: " + erro.getMessage());
		}
	}

}
