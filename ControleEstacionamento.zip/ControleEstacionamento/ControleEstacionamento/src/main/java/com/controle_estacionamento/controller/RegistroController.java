package com.controle_estacionamento.controller;

import com.controle_estacionamento.dominio.EntidadeDominio;
import com.controle_estacionamento.dominio.Registro;
import com.controle_estacionamento.fachada.RegistroFachada;
import org.springframework.web.bind.annotation.*;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping(path ="/api/registro")
@CrossOrigin(origins = "*")

public class RegistroController{
    private final RegistroFachada registroFachada;

    public RegistroController() throws SQLException {
        this.registroFachada = new RegistroFachada();
    }

    @GetMapping("/")
    public List<EntidadeDominio> listarRegistros() throws SQLException {
        List<EntidadeDominio> regs = new ArrayList<>();
        regs = registroFachada.getAll();
        return regs;
    }

    @GetMapping("/{id}")
    public EntidadeDominio buscarRegistro(@PathVariable int id) throws SQLException {
        EntidadeDominio regs = registroFachada.getById(id);
        return regs;
    }

    @GetMapping("/veiculo/{id}")
    public List<EntidadeDominio> buscarRegistroPorVeiculo(@PathVariable int id) throws SQLException {
        List<EntidadeDominio> regs = registroFachada.getByVeiculoId(id);
        return regs;
    }

    @PostMapping("/")
    public EntidadeDominio adicionarRegistro(@RequestBody Registro regs) throws SQLException {
        return registroFachada.save(regs);
    }

    @PutMapping("/{id}")
    public EntidadeDominio atualizarRegistro(@PathVariable int id,@RequestBody Registro regs) throws SQLException {
        return registroFachada.update(id, regs);
    }

    @DeleteMapping("/{id}")
    public void removerRegistro(@PathVariable int id) throws SQLException {
        registroFachada.delete(id);
    }
}
