package com.controle_estacionamento.dao;

import com.controle_estacionamento.dominio.EntidadeDominio;
import com.controle_estacionamento.dominio.Registro;
import com.controle_estacionamento.dominio.Veiculo;

import java.sql.*;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

public class RegistroDAO implements IDao{
    private Connection conexao;

    public RegistroDAO() throws SQLException {
        conexao = DatabaseConnection.getConnection();
    }

    @Override
    public List<EntidadeDominio> getAll() throws SQLException {
        List<EntidadeDominio> registros = new ArrayList<>();
        String sql = "SELECT r.*, v.* FROM registros r INNER JOIN veiculos v ON r.idVeiculo = v.id";
        PreparedStatement ps = conexao.prepareStatement(sql);
        ResultSet result = ps.executeQuery();
        while (result.next()) {
            registros.add((criarRegistro(result)));
        }
        ps.close();
        return registros;
    }

    @Override
    public EntidadeDominio getById(int id) throws SQLException {
        EntidadeDominio registro = null;
        String sql = "SELECT r.*, v.* FROM registros r INNER JOIN veiculos v ON r.idVeiculo = v.id WHERE r.id = ?";
        PreparedStatement ps = conexao.prepareStatement(sql);
        ps.setInt(1, id);
        ResultSet result = ps.executeQuery();
        if (result.next()){
            registro = criarRegistro(result);
        }
        ps.close();
        return registro;
    }

    public List<EntidadeDominio> getByVeiculoId(int id) throws SQLException {
        List<EntidadeDominio> registros = new ArrayList<>();
        String sql = "SELECT r.*, v.* FROM registros r INNER JOIN veiculos v ON r.idVeiculo = v.id WHERE r.idVeiculo = ?";
        PreparedStatement ps = conexao.prepareStatement(sql);
        ps.setInt(1, id);
        ResultSet result = ps.executeQuery();
        while (result.next()){
            registros.add((criarRegistro(result)));
        }
        ps.close();
        return registros;
    }

    @Override
    public EntidadeDominio save(EntidadeDominio entidadeDominio) throws SQLException {
        Registro registro = (Registro) entidadeDominio;
        String sql = "INSERT INTO registros(dataHoraEntrada, dataHoraSaida, periodoPermanencia, preco, metodoPagamento, idVeiculo) VALUES (?,?,?,?,?,?)";
        PreparedStatement ps = conexao.prepareStatement(sql);
        setDadosRegistro(ps, registro);
        ps.executeUpdate();
        ps.close();
        return registro;
    }

    @Override
    public EntidadeDominio update(int id, EntidadeDominio entidadeDominio) throws SQLException {
        Registro registro = (Registro) entidadeDominio;
        String sql = "UPDATE registros SET dataHoraEntrada = ?, dataHoraSaida = ?, periodoPermanencia = ?, preco = ?, metodoPagamento = ?, idVeiculo = ? WHERE id = ?";
        PreparedStatement ps = conexao.prepareStatement(sql);
        setDadosRegistro(ps, registro);
        ps.setInt(7, id);
        ps.executeUpdate();
        ps.close();
        return registro;
    }

    @Override
    public Boolean delete(int id) throws SQLException {
        String sql = "DELETE FROM registros WHERE id = ?";
        try {
            PreparedStatement ps = conexao.prepareStatement(sql);
            ps.setInt(1, id);
            ps.executeUpdate();
            ps.close();
            return true;
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return null;
    }


    private Registro criarRegistro(ResultSet result) throws SQLException {

        Registro registro = new Registro();
        registro.setId(result.getInt("id"));
        registro.setDataHoraEntrada(result.getTimestamp("dataHoraEntrada").toLocalDateTime());
        registro.setDataHoraSaida(result.getTimestamp("dataHoraSaida") != null ? result.getTimestamp("dataHoraSaida").toLocalDateTime() : null);
        registro.setPeriodoPermanencia(result.getString("periodoPermanencia"));
        registro.setPreco(result.getDouble("preco"));
        registro.setMetodoPagamento(result.getString("metodoPagamento"));

        String sqlVeiculo = "SELECT * FROM veiculos WHERE id = ?";
        PreparedStatement psVeiculo = conexao.prepareStatement(sqlVeiculo);
        psVeiculo.setInt(1, result.getInt("idVeiculo"));
        ResultSet resultVeiculo = psVeiculo.executeQuery();
        if (resultVeiculo.next()) {
            Veiculo veiculo = criarVeiculo(resultVeiculo);
            registro.setVeiculo(veiculo);
        }

        psVeiculo.close();
        return registro;
    }

    private void setDadosRegistro(PreparedStatement ps, Registro registro) throws SQLException {
        ps.setTimestamp(1, Timestamp.valueOf(registro.getDataHoraEntrada()));
        ps.setTimestamp(2, registro.getDataHoraSaida() != null ? Timestamp.valueOf(registro.getDataHoraSaida()) : null);
        ps.setString(3, registro.getPeriodoPermanencia());
        ps.setDouble(4, registro.getPreco());
        ps.setString(5, registro.getMetodoPagamento());
        ps.setInt(6, registro.getVeiculo().getId());
    }

    Veiculo criarVeiculo(ResultSet resultSet) throws SQLException {
        Veiculo veiculo = null;

        String proprietario = resultSet.getString("proprietario");
        String telefone = resultSet.getString("telefone");
        String marca = resultSet.getString("marca");
        String modelo = resultSet.getString("modelo");
        String placa = resultSet.getString("placa");
        String cor = resultSet.getString("cor");
        String observacao = resultSet.getString("observacao");

        veiculo = new Veiculo(proprietario, telefone, placa,modelo,marca,cor,observacao);
        veiculo.setId(resultSet.getInt("id"));
        return veiculo;
    }

    void setDadosVeiculo(PreparedStatement ps, Veiculo veiculo) throws SQLException {
        ps.setString(1, veiculo.getProprietario());
        ps.setString(2, veiculo.getTelefone());
        ps.setString(3, veiculo.getMarca());
        ps.setString(4, veiculo.getModelo());
        ps.setString(5, veiculo.getCor());
        ps.setString(6, veiculo.getPlaca());
        ps.setString(7, veiculo.getObservacao());
    }
}

