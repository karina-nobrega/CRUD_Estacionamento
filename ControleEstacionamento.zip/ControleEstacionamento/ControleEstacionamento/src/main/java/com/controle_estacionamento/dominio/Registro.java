package com.controle_estacionamento.dominio;

import java.time.LocalDate;
import java.time.LocalDateTime;

public class Registro extends EntidadeDominio{
    private LocalDateTime dataHoraEntrada;
    private LocalDateTime dataHoraSaida;
    private String periodoPermanencia;
    private double preco;
    private String metodoPagamento;
    private Veiculo veiculo;

    public Registro(LocalDateTime dataHoraEntrada, LocalDateTime dataHoraSaida, String periodoPermanencia, double preco, String metodoPagamento, Veiculo veiculo) {
        setDataHoraEntrada(dataHoraEntrada);
        setDataHoraSaida(dataHoraSaida);
        setPeriodoPermanencia(periodoPermanencia);
        setPreco(preco);
        setMetodoPagamento(metodoPagamento);
        setVeiculo(veiculo);
    }

    public Registro() {

    }

    public LocalDateTime getDataHoraEntrada() {
        return dataHoraEntrada;
    }

    public void setDataHoraEntrada(LocalDateTime dataHoraEntrada) {
        this.dataHoraEntrada = dataHoraEntrada;
    }

    public LocalDateTime getDataHoraSaida() {
        return dataHoraSaida;
    }

    public void setDataHoraSaida(LocalDateTime dataHoraSaida) {
        this.dataHoraSaida = dataHoraSaida;
    }

    public String getPeriodoPermanencia() { return periodoPermanencia; }

    public void setPeriodoPermanencia(String periodoPermanencia) { this.periodoPermanencia = periodoPermanencia; }

    public double getPreco() {
        return preco;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public String getMetodoPagamento() {
        return metodoPagamento;
    }

    public void setMetodoPagamento(String metodoPagamento) {
        this.metodoPagamento = metodoPagamento;
    }

    public Veiculo getVeiculo() {
        return veiculo;
    }

    public void setVeiculo(Veiculo veiculo) {
        this.veiculo = veiculo;
    }

    @Override
    public String toString() {
        return "Registro{" +
                "dataHoraEntrada=" + dataHoraEntrada +
                ", dataHoraSaida=" + dataHoraSaida +
                ", periodoPermanencia='" + periodoPermanencia + '\'' +
                ", preco=" + preco +
                ", metodoPagamento='" + metodoPagamento + '\'' +
                ", veiculo=" + veiculo +
                '}';
    }
}
