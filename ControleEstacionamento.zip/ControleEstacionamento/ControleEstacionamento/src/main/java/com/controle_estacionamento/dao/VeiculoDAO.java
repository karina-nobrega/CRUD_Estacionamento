package com.controle_estacionamento.dao;

import com.controle_estacionamento.dominio.EntidadeDominio;
import com.controle_estacionamento.dominio.Veiculo;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class VeiculoDAO implements IDao{
    private Connection conexao;

    public VeiculoDAO() throws SQLException {
        conexao = DatabaseConnection.getConnection();
    }

    @Override
    public List<EntidadeDominio> getAll() throws SQLException {
        List<EntidadeDominio> veics = new ArrayList<>();
        String sql = "SELECT * FROM veiculos";
        PreparedStatement ps = conexao.prepareStatement(sql);
        ResultSet result = ps.executeQuery();
        while (result.next()) {
            veics.add((criarVeiculo(result)));
        }
        ps.close();
        return veics;
    }

    @Override
    public EntidadeDominio getById(int id) throws SQLException {
        EntidadeDominio veiculo = null;
        String sql = "SELECT * FROM veiculos WHERE id = ?";
        PreparedStatement ps = conexao.prepareStatement(sql);
        ps.setInt(1, id);
        ResultSet result = ps.executeQuery();
        if (result.next()) {
            veiculo = criarVeiculo(result);
        }
        ps.close();
        return veiculo;
    }

    @Override
    public EntidadeDominio save(EntidadeDominio entidadeDominio) throws SQLException {
        Veiculo veiculo = (Veiculo) entidadeDominio;
        String sql = "INSERT INTO veiculos(proprietario, telefone, marca, modelo, cor, placa, observacao) VALUES (?,?,?,?,?,?,?)";
        PreparedStatement ps = conexao.prepareStatement(sql, PreparedStatement.RETURN_GENERATED_KEYS);
        setDadosVeiculo(ps, veiculo);
        ps.execute();
        ResultSet result = ps.getGeneratedKeys();
        if (result.next()) {
            veiculo.setId(result.getInt(1));
        }
        return veiculo;
    }

    @Override
    public EntidadeDominio update(int id, EntidadeDominio entidadeDominio) throws SQLException {
        Veiculo veiculo = (Veiculo) entidadeDominio;
        String sql = "UPDATE veiculos SET proprietario = ?, telefone = ?, marca = ?, modelo = ?, cor = ?, placa = ?, observacao = ? WHERE id = ?";
        PreparedStatement ps = conexao.prepareStatement(sql);
        setDadosVeiculo(ps, veiculo);
        ps.setInt(8, id);
        ps.executeUpdate();
        ps.close();
        veiculo.setId(id);
        return veiculo;

    }

    @Override
    public Boolean delete(int id) throws SQLException {
        String sql = "DELETE FROM veiculos WHERE id = ?";
        try{
            PreparedStatement ps = conexao.prepareStatement(sql);
            ps.setInt(1, id);
            ps.executeUpdate();
            ps.close();
            return true;
        }
        catch (SQLException error) {
            throw new SQLException(error.getMessage());
        }
    }

    Veiculo criarVeiculo(ResultSet resultSet) throws SQLException {
        Veiculo veiculo = null;

        String proprietario = resultSet.getString("proprietario");
        String telefone = resultSet.getString("telefone");
        String marca = resultSet.getString("marca");
        String modelo = resultSet.getString("modelo");
        String placa = resultSet.getString("placa");
        String cor = resultSet.getString("cor");
        String observacao = resultSet.getString("observacao");

        veiculo = new Veiculo(proprietario, telefone, placa,modelo,marca,cor,observacao);
        veiculo.setId(resultSet.getInt("id"));
        return veiculo;

    }

    void setDadosVeiculo(PreparedStatement ps, Veiculo veiculo) throws SQLException {
        ps.setString(1, veiculo.getProprietario());
        ps.setString(2, veiculo.getTelefone());
        ps.setString(3, veiculo.getMarca());
        ps.setString(4, veiculo.getModelo());
        ps.setString(5, veiculo.getCor());
        ps.setString(6, veiculo.getPlaca());
        ps.setString(7, veiculo.getObservacao());
    }

}
