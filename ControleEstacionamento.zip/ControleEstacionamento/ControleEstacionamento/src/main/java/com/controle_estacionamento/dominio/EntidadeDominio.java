package com.controle_estacionamento.dominio;

public abstract class EntidadeDominio {

    public int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }
}
