package com.controle_estacionamento.controller;

import com.controle_estacionamento.dominio.EntidadeDominio;
import com.controle_estacionamento.dominio.Veiculo;
import com.controle_estacionamento.fachada.IFachada;
import com.controle_estacionamento.fachada.VeiculoFachada;
import org.springframework.web.bind.annotation.*;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping(path ="/api/veiculo")
@CrossOrigin(origins = "*")
public class VeiculoController{
    private final VeiculoFachada veiculoFachada;

    public VeiculoController() throws SQLException {
        this.veiculoFachada = new VeiculoFachada();
    }

    @GetMapping("/")
    public List<EntidadeDominio> listarVeiculos() throws SQLException {
        List<EntidadeDominio> veics = new ArrayList<>();
        veics = veiculoFachada.getAll();
        return veics;
    }

    @GetMapping("/{id}")
    public EntidadeDominio buscarVeiculo(@PathVariable int id) throws SQLException {
        EntidadeDominio veic = veiculoFachada.getById(id);
        return veic;
    }

    @PostMapping("/")
    public EntidadeDominio adicionarVeiculo(@RequestBody Veiculo veic) throws SQLException {
        return veiculoFachada.save(veic);
    }

    @PutMapping("/{id}")
    public EntidadeDominio atualizarVeiculo(@PathVariable int id,@RequestBody Veiculo veic) throws SQLException {
        return veiculoFachada.update(id, veic);
    }

    @DeleteMapping("/{id}")
    public void removerVeiculo(@PathVariable int id) throws SQLException {
        veiculoFachada.delete(id);
    }

}
