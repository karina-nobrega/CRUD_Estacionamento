package com.controle_estacionamento.fachada;

import com.controle_estacionamento.dominio.EntidadeDominio;

import java.sql.SQLException;
import java.util.List;

public interface IFachada {
    List<EntidadeDominio> getAll() throws SQLException;
    EntidadeDominio getById(int id) throws SQLException;
    EntidadeDominio save(EntidadeDominio entidadeDominio) throws SQLException;
    EntidadeDominio update(int id, EntidadeDominio entidadeDominio) throws SQLException;
    Boolean delete(int id) throws SQLException;
}
