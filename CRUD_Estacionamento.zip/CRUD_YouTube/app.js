document.addEventListener("DOMContentLoaded", () => {
  let apiUrl = "http://localhost:8080/api/registro/";
  let apiUrlVeiculo = "http://localhost:8080/api/veiculo/";

  const buscarRegistros = () => {
    return fetch(apiUrl)
      .then((response) => {
        if (!response.ok) {
          throw new Error("Erro ao carregar os dados da API.");
        }
        return response.json();
      })
      .then((data) => {
        return data; // Retorna os dados, se necessário
      });
  };

  const consultarRegistro = (id) => {
    let url = `${apiUrl}${id}`;
    return fetch(url)
      .then((response) => {
        if (!response.ok) {
          throw new Error("Erro ao carregar os dados da API.");
        }
        return response.json();
      })
      .then((data) => {
        return data; // Retorna os dados, se necessário
      });
  };

  const consultarVeiculo = (id) => {
    let url = `${apiUrlVeiculo}${id}`;
    return fetch(url)
      .then((response) => {
        if (!response.ok) {
          throw new Error("Erro ao carregar os dados da API.");
        }
        return response.json();
      })
      .then((data) => {
        return data; // Retorna os dados, se necessário
      });
  };

  const deletarRegistro = (id) => {
    let url = `${apiUrl}${id}`;
    return fetch(url, {
      method: "DELETE",
    })
      .then((response) => {
        if (!response.ok) {
          throw new Error("Erro ao deletar o registro.");
        }
        return id; // Retorna o ID do registro deletado, se necessário
      })
      .catch((error) => {
        console.error("Erro ao deletar o registro:", error);
        throw error; // Propaga o erro para ser tratado pela função chamadora
      });
  };

  let newMemberAddBtn = document.querySelector(".addMemberBtn"),
    darkBg = document.querySelector(".dark_bg"),
    popupForm = document.querySelector(".popup"),
    crossBtn = document.querySelector(".closeBtn"),
    submitBtn = document.querySelector(".submitBtn"),
    cancelarBtn = document.querySelector(".cancelarBtn"),
    modalTitle = document.querySelector(".modalTitle"),
    popupFooter = document.querySelector(".popupFooter"),
    form = document.querySelector("form"),
    formInputFields = document.querySelectorAll("form input"),
    proprietario = document.getElementById("proprietario"),
    telefone = document.getElementById("telefone"),
    placa = document.getElementById("placa"),
    marca = document.getElementById("marca"),
    modelo = document.getElementById("modelo"),
    cor = document.getElementById("cor"),
    dataHoraEntrada = document.getElementById("dataHoraEntrada"),
    dataHoraSaida = document.getElementById("dataHoraSaida"),
    periodoPermanencia = document.getElementById("periodoPermanencia"),
    observacao = document.getElementById("observacao"),
    preco = document.getElementById("preco"),
    metodoPagamento = document.getElementById("metodoPagamento"),
    userInfo = document.querySelector(".userInfo"),
    table = document.querySelector("table"),
    filterData = document.getElementById("search");

  let originalData = JSON.parse(localStorage.getItem("userProfile")) || [];

  showInfo();

  // Estilo para as linhas encerradas
  const style = document.createElement("style");
  style.innerHTML = `
        .encerrado {
          background-color: rgba(100, 0, 0) !important;
          color: white;
        }
        .hidden {
          display: none;
        }
    `;
  document.head.appendChild(style);

  newMemberAddBtn.addEventListener("click", () => {
    isEdit = false;
    submitBtn.innerHTML = "Cadastrar";
    cancelarBtn.innerHTML = "Cancelar";
    modalTitle.innerHTML = "Cadastrar Veículo";
    popupFooter.style.display = "block";
    darkBg.classList.add("active");
    popupForm.classList.add("active");
  });

  crossBtn.addEventListener("click", () => {
    darkBg.classList.remove("active");
    popupForm.classList.remove("active");
  });

  cancelarBtn.addEventListener("click", (e) => {
    e.preventDefault();
    darkBg.classList.remove("active");
    popupForm.classList.remove("active");
  });

  //Quantidade de registros por página.
  function showInfo() {
    buscarRegistros()
      .then((data) => {
        userInfo.innerHTML = "";
        const fragment = document.createDocumentFragment();
        if (data.length > 0) {
          data.forEach((el, index) => {
            const staff = el;
            if (staff) {
              const row = document.createElement("tr");
              row.classList.add("employeeDetails");
              if (staff.dataHoraSaida) {
                row.classList.add("encerrado");
              }
              row.innerHTML = ` 
                <td>${staff.id}</td>
                <td>${staff.veiculo.placa}</td>
                <td>${staff.veiculo.proprietario}</td>
                <td>${staff.veiculo.telefone}</td>
                <td>${staff.dataHoraEntrada}</td>
                <td>${
                  staff.dataHoraSaida != null ? staff.dataHoraSaida : "Estacionado"
                }</td>
                <td>${staff.periodoPermanencia}</td>
                <td>${
                  staff.preco != null ? staff.preco : "R$ 0,00"
                }</td>
                <td>
                    <button title="Visualizar" onclick="readInfo(${
                      staff.id
                    })"><i class="bi bi-eye"></i></button>
                    <button title="Editar" onclick="editInfo(${
                      staff.veiculo.id
                    })"><i class="bi bi-pencil-square"></i></button>
                    <button title="Encerrar" onclick="closeInfo(${
                      staff.id
                    })"><i class="bi bi-journal-check"></i></button>
                    <button title="Deletar" onclick="deleteInfo(${
                      staff.id
                    })"><i class="bi bi-trash3"></i></button>
                </td>
              `;
              fragment.appendChild(row);
            }
          });
        } else {
          const row = document.createElement("tr");
          row.classList.add("employeeDetails");
          row.innerHTML = `<td class="empty" colspan="11" align="center"> Sem dados disponíveis na tabela</td>`;
          fragment.appendChild(row);
        }

        userInfo.appendChild(fragment);
        table.style.minWidth = "1000px";
      })
      .catch((error) => {
        console.error(error);
      });
  }

  //Visualizar informações cadastradas do veículo, entrada e proprietário
  function readInfo(index) {
    consultarRegistro(index)
      .then((data) => {
        const registro = data;
        if (registro) {
          document.getElementById("placa").value = registro.veiculo.placa;
          document.getElementById("proprietario").value =
            registro.veiculo.proprietario;
          document.getElementById("telefone").value = registro.veiculo.telefone;
          document.getElementById("marca").value = registro.veiculo.marca;
          document.getElementById("modelo").value = registro.veiculo.modelo;
          document.getElementById("cor").value = registro.veiculo.cor;
          document.getElementById("dataHoraEntrada").value =
            registro.dataHoraEntrada;
          document.getElementById("dataHoraSaida").value =
            registro.dataHoraSaida;
          document.getElementById("periodoPermanencia").value =
            registro.periodoPermanencia;
          document.getElementById("preco").value = registro.preco;
          document.getElementById("metodoPagamento").value =
            registro.metodoPagamento;
          document.getElementById("observacao").value =
            registro.veiculo.observacao;

          dtE.hidden = false;
          dtS.hidden = false;
          pP.hidden = false;

          darkBg.classList.add("active");
          popupForm.classList.add("active");
          popupFooter.style.display = "none";
          modalTitle.innerHTML = "Detalhes do Veículo";

          formInputFields.forEach((input) => {
            input.disabled = true;
          });
        }
      })
      .catch((error) => {
        console.error(error);
      });
  }

  //Editar Cadastro
  let editVehicleId = null;

  function editInfo(index) {
    consultarVeiculo(index).then((data) => {
      const staff = data;
      if (staff) {
        editVehicleId = staff.id;
        document.getElementById("placa").value = staff.placa;
        document.getElementById("proprietario").value = staff.proprietario;
        document.getElementById("telefone").value = staff.telefone;
        document.getElementById("marca").value = staff.marca;
        document.getElementById("modelo").value = staff.modelo;
        document.getElementById("cor").value = staff.cor;
        document.getElementById("observacao").value = staff.observacao;

        darkBg.classList.add("active");
        popupForm.classList.add("active");
        popupFooter.style.display = "block";
        modalTitle.innerHTML = "Editar Veículo";
        submitBtn.innerHTML = "Salvar";
        cancelarBtn.innerHTML = "Cancelar";

        formInputFields.forEach((input) => {
          input.disabled = false;
        });
      }
    });
  }

  let registroId = null;
  //Encerrar permanencia do veículo estacionado
  function closeInfo(index) {
    consultarRegistro(index).then((data) => {
      const staff = data;
      if (staff) {
        registroId = index;
        editVehicleId = staff.veiculo.id;
        document.getElementById("placa").value = staff.veiculo.placa;
        document.getElementById("proprietario").value =
          staff.veiculo.proprietario;
        document.getElementById("telefone").value = staff.veiculo.telefone;
        document.getElementById("marca").value = staff.veiculo.marca;
        document.getElementById("modelo").value = staff.veiculo.modelo;
        document.getElementById("cor").value = staff.veiculo.cor;
        document.getElementById("dataHoraEntrada").value =
          staff.dataHoraEntrada;
        document.getElementById("dataHoraSaida").value = staff.dataHoraSaida;
        document.getElementById("periodoPermanencia").value =
          staff.periodoPermanencia;
        document.getElementById("preco").value = staff.preco;
        document.getElementById("metodoPagamento").value =
          staff.metodoPagamento;
        document.getElementById("observacao").value = staff.veiculo.observacao;

        dtE.hidden = false;
        dtE.required = true;
        dtS.hidden = false;
        dtS.required = true;
        pP.hidden = false;

        darkBg.classList.add("active");
        popupForm.classList.add("active");
        modalTitle.innerHTML = "Encerrar Permanência do Veículo";
        submitBtn.innerHTML = "Encerrar";
        cancelarBtn.innerHTML = "Cancelar";

        formInputFields.forEach((input) => {
          input.disabled =
            input.id !== "dataHoraSaida" &&
            input.id !== "preco" &&
            input.id !== "metodoPagamento";
        });
      }
    });
  }

  //Deletar cadastro/registro
  function deleteInfo(index) {
    // Exibir confirmação ao usuário
    if (confirm("Certeza de que deseja excluir o registro deste Veículo?")) {
      // Chamada assíncrona para deletar o registro
      deletarRegistro(index)
        .then((data) => {
          // Remover o registro do `originalData` pelo índice retornado
          originalData.splice(data, 1);

          // Atualizar o localStorage com os dados atualizados
          localStorage.setItem("userProfile", JSON.stringify(originalData));

          // Atualizar o array `getData` com os dados atualizados
          getData = [...originalData];

          // Atualizar a exibição dos dados e da paginação
          showInfo();
        })
        .catch((error) => {
          console.error("Erro ao deletar o registro:", error);
          // Tratar o erro se necessário
        });
    }
  }

  form.addEventListener("submit", (e) => {
    e.preventDefault();

    let staffData = {
      placa: placa ? placa.value : "",
      proprietario: proprietario ? proprietario.value : "",
      telefone: telefone ? telefone.value : "",
      marca: marca ? marca.value : "",
      modelo: modelo ? modelo.value : "",
      cor: cor ? cor.value : "",
      observacao: observacao ? observacao.value : "",
      dataHoraEntrada: dataHoraEntrada ? dataHoraEntrada.value : "",
      dataHoraSaida: dataHoraSaida ? dataHoraSaida.value : "",
      periodoPermanencia: periodoPermanencia ? periodoPermanencia.value : "",
      preco: preco ? preco.value : "",
      metodoPagamento: metodoPagamento ? metodoPagamento.value : "",
    };

    if (submitBtn.innerHTML === "Encerrar" && editVehicleId !== null) {
      let staffData = {
        veiculo: {
          id: editVehicleId,
        },
        dataHoraEntrada: dataHoraEntrada ? dataHoraEntrada.value : "",
        dataHoraSaida: dataHoraSaida ? dataHoraSaida.value : "",
        periodoPermanencia: periodoPermanencia ? periodoPermanencia.value : "",
        preco: preco ? preco.value : "",
        metodoPagamento: metodoPagamento ? metodoPagamento.value : "",
      };
      // Enviar dados de encerramento para o servidor
      fetch(`http://localhost:8080/api/registro/${registroId}`, {
        method: "PUT", // ou 'PATCH', dependendo da API
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(staffData),
      })
        .then((response) => {
          if (!response.ok) {
            throw new Error("Erro ao atualizar os dados.");
          }
          showInfo();
          return response;
        })
        .then((updatedData) => {
          buscarRegistros().then((data) => {
            originalData = data;
            getData = [...originalData];
          });
        })
        .catch((error) => {
          console.error("Erro:", error);
        });
    }

    darkBg.classList.remove("active");
    popupForm.classList.remove("active");

    if (editVehicleId !== null) {
      // Enviar dados de edição para o servidor
      fetch(`http://localhost:8080/api/veiculo/${editVehicleId}`, {
        method: "PUT", // ou 'PATCH', dependendo da API
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(staffData),
      })
        .then((response) => {
          if (!response.ok) {
            throw new Error("Erro ao atualizar os dados.");
          }
          showInfo();
          return response;
        })
        .then((updatedData) => {
          console.log("Veículo atualizado com sucesso:", updatedData);
          // Atualizar o localStorage ou buscar os dados novamente
          buscarRegistros().then((data) => {
            originalData = data;
            getData = [...originalData];
          });
        })
        .catch((error) => {
          console.error("Erro:", error);
        });
    } else {
      fetch(`http://localhost:8080/api/veiculo/`, {
        method: "POST", // ou 'PATCH', dependendo da API
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(staffData),
      })
        .then((response) => {
          if (!response.ok) {
            throw new Error("Erro ao atualizar os dados.");
          }
          showInfo();
          return response.json();
        })
        .then((data) => {
          staffData.veiculo = {
            id: data.id,
          };

          fetch(`http://localhost:8080/api/registro/`, {
            method: "POST", // ou 'PATCH', dependendo da API
            headers: {
              "Content-Type": "application/json",
            },
            body: JSON.stringify(staffData),
          });
        });
    }

    form.reset();
    showInfo();
    darkBg.classList.remove("active");
    popupForm.classList.remove("active");
  });

  // Filtra os dados de acordo com a busca
  filterData.addEventListener("input", () => {
    const searchTerm = filterData.value.toLowerCase().trim();

    if (searchTerm !== "") {
      const filteredData = originalData.filter((item) => {
        const placa = item.veiculo.placa.toLowerCase().trim();
        const proprietario = item.veiculo.proprietario.toLowerCase().trim();

        return placa.includes(searchTerm) || proprietario.includes(searchTerm);
      });

      // Atualiza os dados atuais com os dados filtrados
      getData = filteredData;
    } else {
      // Restaura os dados originais do localStorage
      getData = JSON.parse(localStorage.getItem("userProfile")) || [];
    }
  });

  window.readInfo = readInfo;
  window.editInfo = editInfo;
  window.closeInfo = closeInfo;
  window.deleteInfo = deleteInfo;
});
